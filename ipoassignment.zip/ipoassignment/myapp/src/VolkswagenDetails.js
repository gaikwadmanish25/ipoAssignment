import React from 'react';
import './volkswagenDetails.css'; 
import logo from './image/companyI.jpg'; 
import download from './image/download.png'; 

function VolkswagenDetails() {
  return (
    <div className="container">
      <nav className="navbar">
        <ul className="nav-links">
          <li><a href="/">Home</a></li>
          <li><a href="/service">Service</a></li>
          <li><a href="/contact">Contact</a></li>
        </ul>
        <img src={download} alt="Download" className="download-image" />
      </nav>
      <div className="main-content">
        <div className="header">
          <div className="logo-name">
            <img src={logo} alt="Company Logo" className="logo" />
            <span className="company-name">Volkswagen</span>
          </div>
          <button className="apply-now">Apply Now</button>
        </div>
        <div className="details-box">
          <ul>
            <li>Issue Size: ₹1,000,000</li>
            <li>Price Range: ₹10 - ₹15</li>
            <li>Minimum Amount: ₹1,000</li>
            <li>Lot Size: 100 shares</li>
          </ul>
          <ul>
            <li>Issue Date: 2024-05-01</li>
            <li>Listed On: BSE, NSE</li>
            <li>Listed Price: ₹12</li>
            <li>Listed Gains: 20%</li>
          </ul>
        </div>
      </div>
      <footer className="footer">
        <h3>About Company</h3>
        <p>"Celebrating a legacy of innovation and craftsmanship, Volkswagen stands as an emblem of excellence in the automotive industry. Committed to sustainable progress and societal well-being, we strive to shape a brighter future for all. Our diverse lineup of vehicles, from compact cars to luxury sedans, reflects our unwavering dedication to quality and customer satisfaction. At Volkswagen, we value enduring partnerships built on mutual trust and respect. Guided by our core values, we embrace challenges as opportunities for growth, propelling progress both locally and globally. Join us on our journey towards a more inclusive and prosperous world. Together, let's redefine possibilities and inspire generations to come. Welcome to Volkswagen, where excellence drives purpose."</p>
      </footer>
    </div>
  );
}

export default VolkswagenDetails;

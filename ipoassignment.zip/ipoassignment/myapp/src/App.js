import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';



import './App.css';
import logo from './image/download.png'; 
import TataDetails from './TataDetails.js';
import MahindraDetails from './MahindraDetails.js';
import SuzukiDetails from './SuzukiDetails.js';
import ToyotaDetails from './ToyotaDetails.js';
import BajajDetails from './BajajDetails.js';
import HondaDetails from './HondaDetails.js';
import SkodaDetails from './SkodaDeatils.js';
import HyundaiDetails from './HyundaiDetails.js';
import VolkswagenDetails from './VolkswagenDetails.js';



// Import company logos
import companyALogo from './image/companyA.jpg';
import companyBLogo from './image/companyB.png';
import companyCLogo from './image/companyC.png';
import companyDLogo from './image/companyD.jpg';
import companyELogo from './image/companyE.jpg';
import companyFLogo from './image/companyF.jpg';
import companyGLogo from './image/companyG.jpg'; 
import companyHLogo from './image/companyH.png';
import companyILogo from './image/companyI.jpg';

function App() {
  const [showInitialPage, setShowInitialPage] = useState(false);

  const handleShowInitialPage = () => {
    setShowInitialPage(true);
  };
  return (
    <Router>
    <div className="App" style={{ display: showInitialPage ? 'none' : 'block' }}>
      <nav>
        <img src={logo} alt="Logo" className="logo" />
        
        <ul className="nav-links">
          <li><a href="#home">Home</a></li>
          <li><a href="#contact">Contact</a></li>
          <li><a href="#service">Service</a></li>
        </ul>
      </nav>
      
      <section className="ipo-list">
        <h3>IPO list page</h3>
        <table>
          <thead>
            <tr>
              <th>Company/Issue Date</th>
              <th>Issue Size</th>
              <th>Price Range</th>
              <th>Min Invest/Quantity</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <img src={companyALogo} alt="Company A Logo" className="company-logo" />
                TATA
                <br />
                <span className="issue-date">2024-05-01</span>
              </td>
              <td>₹1,000,000</td>
              <td>₹10 - ₹15</td>
              <td>100 shares</td>
              <td>
               <Link to="/tata" onClick={handleShowInitialPage}>details</Link>
                </td>
            </tr>
            <tr>
              <td>
                <img src={companyBLogo} alt="Company B Logo" className="company-logo" />
                Mahindra
                <br />
                <span className="issue-date">2024-06-15</span>
              </td>
              <td>₹500,000</td>
              <td>₹20 - ₹25</td>
              <td>50 shares</td>
              <td>
              <Link to="/mahindra" onClick={handleShowInitialPage}>details</Link>
                </td>
            </tr>
            <tr>
              <td>
                <img src={companyCLogo} alt="Company C Logo" className="company-logo" />
                Suzuki
                <br />
                <span className="issue-date">2024-07-20</span>
              </td>
              <td>₹750,000</td>
              <td>₹30 - ₹35</td>
              <td>75 shares</td>
              <td>
              <Link to="/suzuki" onClick={handleShowInitialPage}>details</Link>
                </td>
            </tr>
            <tr>
              <td>
                <img src={companyDLogo} alt="Company D Logo" className="company-logo" />
                Toyota
                <br />
                <span className="issue-date">2024-08-05</span>
              </td>
              <td>₹1,200,000</td>
              <td>₹50 - ₹55</td>
              <td>120 shares</td>
              <td>
              <Link to="/toyota" onClick={handleShowInitialPage}>details</Link>
                </td>
            </tr>
            <tr>
              <td>
                <img src={companyELogo} alt="Company E Logo" className="company-logo" />
                Hyundai
                <br />
                <span className="issue-date">2024-08-05</span>
              </td>
              <td>₹1,200,000</td>
              <td>₹50 - ₹55</td>
              <td>120 shares</td>
              <td>
              <Link to="/Hyundai" onClick={handleShowInitialPage}>details</Link>
                </td>
            </tr>
            <tr>
              <td>
                <img src={companyFLogo} alt="Company F Logo" className="company-logo" />
                Bajaj
                <br />
                <span className="issue-date">2024-08-05</span>
              </td>
              <td>₹1,200,000</td>
              <td>₹50 - ₹55</td>
              <td>120 shares</td>
              <td>
              <Link to="/bajaj" onClick={handleShowInitialPage}>details</Link>
                </td>
            </tr>
            <tr>
              <td>
                <img src={companyGLogo} alt="Company G Logo" className="company-logo" />
                Honda
                <br />
                <span className="issue-date">2024-08-05</span>
              </td>
              <td>₹1,200,000</td>
              <td>₹50 - ₹55</td>
              <td>120 shares</td>
              <td>
              <Link to="/honda" onClick={handleShowInitialPage}>details</Link>
                </td>
            </tr>
            <tr>
              <td>
                <img src={companyHLogo} alt="Company H Logo" className="company-logo" />
                Skoda
                <br />
                <span className="issue-date">2024-08-05</span>
              </td>
              <td>₹1,200,000</td>
              <td>₹50 - ₹55</td>
              <td>120 shares</td>
              <td>
              <Link to="/skoda" onClick={handleShowInitialPage}>details</Link>
                </td>
            </tr>
            <tr>
              <td>
                <img src={companyILogo} alt="Company I Logo" className="company-logo" />
                Volkswagen
                <br />
                <span className="issue-date">2024-08-05</span>
              </td>
              <td>₹1,200,000</td>
              <td>₹50 - ₹55</td>
              <td>120 shares</td>
              <td>
              <Link to="/volkswagen" onClick={handleShowInitialPage}>details</Link>
                </td>
            </tr>
            
            {/* Add more rows as needed */}
          </tbody>
        </table>
      </section>

       {/* IPO Details Page Button */}
      
     
    </div>

     {/* Define Routes */}
     
     
     {/* Add more routes as needed */}
     <Routes>
        <Route path="/tata" element={<TataDetails />} />
        <Route path="/mahindra" element={<MahindraDetails />} />
        <Route path="/suzuki" element={<SuzukiDetails/>} />
        <Route path="/toyota" element={<ToyotaDetails/>} />
        <Route path="/hyundai" element={<HyundaiDetails />} />
        <Route path="/bajaj" element={<BajajDetails />} />
        <Route path="/honda" element={<HondaDetails />} />
        <Route path="/skoda" element={<SkodaDetails />} />
        <Route path="/volkswagen" element={<VolkswagenDetails/>} />
        {/* Add more routes as needed */}
      </Routes>
  
 </Router>
  );
}

export default App;

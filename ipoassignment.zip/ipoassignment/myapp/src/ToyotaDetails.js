import React from 'react';
import './toyotaDetails.css'; 
import logo from './image/companyD.jpg'; 
import download from './image/download.png'; 

function ToyotaDetails() {
  return (
    <div className="container">
      <nav className="navbar">
        <ul className="nav-links">
          <li><a href="/">Home</a></li>
          <li><a href="/service">Service</a></li>
          <li><a href="/contact">Contact</a></li>
        </ul>
        <img src={download} alt="Download" className="download-image" />
      </nav>
      <div className="main-content">
        <div className="header">
          <div className="logo-name">
            <img src={logo} alt="Company Logo" className="logo" />
            <span className="company-name">Toyota</span>
          </div>
          <button className="apply-now">Apply Now</button>
        </div>
        <div className="details-box">
          <ul>
            <li>Issue Size: ₹1,000,000</li>
            <li>Price Range: ₹10 - ₹15</li>
            <li>Minimum Amount: ₹1,000</li>
            <li>Lot Size: 100 shares</li>
          </ul>
          <ul>
            <li>Issue Date: 2024-05-01</li>
            <li>Listed On: BSE, NSE</li>
            <li>Listed Price: ₹12</li>
            <li>Listed Gains: 20%</li>
          </ul>
        </div>
      </div>
      <footer className="footer">
        <h3>About Company</h3>
        <p>"Celebrating a legacy of innovation and dependability, Toyota stands as an enduring symbol of excellence. Dedicated to sustainable progress and societal well-being, we are committed to shaping a brighter tomorrow. Our extensive array of products, spanning from cars to hybrid technologies, reflects our unwavering commitment to quality and customer satisfaction. At Toyota, we cherish enduring partnerships grounded in mutual trust and respect. Guided by our core values, we embrace challenges as catalysts for growth, driving progress on a global scale. Join us on our journey towards a more inclusive and prosperous future. Together, let's redefine limits and inspire future generations. Welcome to Toyota, where excellence is seamlessly integrated with purpose."</p>
      </footer>
    </div>
  );
}

export default ToyotaDetails;



import React from 'react';
import './suzukiDetails.css'; 
import logo from './image/companyC.png'; 
import download from './image/download.png'; 

function SuzukiDetails() {
  return (
    <div className="container">
      <nav className="navbar">
        <ul className="nav-links">
          <li><a href="/">Home</a></li>
          <li><a href="/service">Service</a></li>
          <li><a href="/contact">Contact</a></li>
        </ul>
        <img src={download} alt="Download" className="download-image" />
      </nav>
      <div className="main-content">
        <div className="header">
          <div className="logo-name">
            <img src={logo} alt="Company Logo" className="logo" />
            <span className="company-name">Suzuki</span>
          </div>
          <button className="apply-now">Apply Now</button>
        </div>
        <div className="details-box">
          <ul>
            <li>Issue Size: ₹1,000,000</li>
            <li>Price Range: ₹10 - ₹15</li>
            <li>Minimum Amount: ₹1,000</li>
            <li>Lot Size: 100 shares</li>
          </ul>
          <ul>
            <li>Issue Date: 2024-05-01</li>
            <li>Listed On: BSE, NSE</li>
            <li>Listed Price: ₹12</li>
            <li>Listed Gains: 20%</li>
          </ul>
        </div>
      </div>
      <footer className="footer">
      <h3>About Company</h3>
        <p>
        "Celebrating a heritage of innovation and reliability, Suzuki stands as an icon of excellence. Committed to sustainable progress and societal welfare, we endeavor to shape a brighter tomorrow. Our extensive range of products, from automobiles to motorcycles, mirrors our steadfast dedication to quality and customer satisfaction. At Suzuki, we value enduring partnerships built on mutual trust and respect. Guided by our principles, we embrace challenges as opportunities for growth, propelling advancement worldwide. Join us on our journey toward a more inclusive and prosperous future. Together, let's redefine boundaries and inspire generations to come. Welcome to Suzuki, where excellence is infused with purpose."
       </p>
      </footer>
    </div>
  );
}

export default SuzukiDetails;

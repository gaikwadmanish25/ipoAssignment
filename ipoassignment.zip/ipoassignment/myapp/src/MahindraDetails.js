import React from 'react';
import './mahindraDetails.css'; 
import logo from './image/companyB.png'; 
import download from './image/download.png';

function MahindraDetails() {
  return (
    <div className="container">
      <nav className="navbar">
        <ul className="nav-links">
          <li><a href="/">Home</a></li>
          <li><a href="/service">Service</a></li>
          <li><a href="/contact">Contact</a></li>
        </ul>
        <img src={download} alt="Download" className="download-image" />
      </nav>
      <div className="main-content">
        <div className="header">
          <div className="logo-name">
            <img src={logo} alt="Company Logo" className="logo" />
            <span className="company-name">Mahindra</span>
          </div>
          <button className="apply-now">Apply Now</button>
        </div>
        <div className="details-box">
          <div className="details-row">
            <ul className="details-list">
              <li>Issue Size: ₹1,200,000</li>
              <li>Price Range: ₹12 - ₹18</li>
              <li>Minimum Amount: ₹1,200</li>
              <li>Lot Size: 120 shares</li>
            </ul>
          </div>
          <div className="details-row">
            <ul className="details-list">
              <li>Issue Date: 2024-06-01</li>
              <li>Listed On: BSE, NSE</li>
              <li>Listed Price: ₹15</li>
              <li>Listed Gains: 25%</li>
            </ul>
          </div>
        </div>
      </div>
      <footer className="footer">
      <h3>About Company</h3>
        <p>
       "Celebrating a legacy of innovation and integrity, Mahindra stands as a beacon of excellence. With a commitment to sustainable growth and societal well-being, we strive to shape a brighter future. Our diverse portfolio, spanning industries from steel to software, reflects our unwavering dedication to quality and service. At Mahindra, we believe in fostering enduring relationships, built on trust and respect. Guided by our values, we embrace challenges as opportunities for growth, driving progress across the globe. Join us on our journey towards a more inclusive and prosperous world. Together, let's redefine possibilities and inspire generations to come. Welcome to Tata, where excellence meets purpose."
       </p>
      </footer>
    </div>
  );
}

export default MahindraDetails;
